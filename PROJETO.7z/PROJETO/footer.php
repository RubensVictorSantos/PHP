<?php

    echo(
        '
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <div id="footer" class="center">
            <div id="main-footer" class="center">
                <div class="conteudo-footer">
                    <div id="logo-footer">
                        <a href="index.php" title="Logotipo" >
                            <img src="img/ico/logo.png" style=" " alt="bicicleta logo da empresa" id="imag-logo-footer">
                        </a>
                    </div>
                </div>
                <div class="conteudo-footer">
                    <h3 class="titulo-footer">Contato</h3>
                    <ul>
                        <li>Home</li>
                        <li>Sobre</li>
                        <li>Serviços</li>
                        <li></li>

                    </ul>
                </div>
                <div class="conteudo-footer">
                    <h3 class="titulo-footer">Contato</h3>
                    <ul>
                        <li>www.roadrunner@gmail.com</li>
                        <li>cel: (11)95880-8525</li>
                        <li>tel: (11)4444-4645</li>
                    </ul>
                </div>
                <div class="conteudo-footer">
                    <h3 class="titulo-footer">Test</h3>
                    <ul>
                        <li> Facebook</li>
                        <li> </li>
                        <li>se fica bom o </li>
                        <li>rodapé</li>
                        <li></li>
                    </ul>
                </div>
            </div>
        </div>'
    );
?>