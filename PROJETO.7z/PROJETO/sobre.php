<!DOCTYPE html>
<html lang="zxx">
    <head>
        <meta charset="utf-8">
        <title>
            Sobre a empresa
        </title>
        <link rel="icon" href="img/ico/i405_TDM_icon_bike93.gif">
    </head>
    <body>
        <?php

            require_once("menu.php");

        ?>
        <div id="conteudo" class="center">
            <div id="conteudo-catalogo" class="center">
                <div>
                <div class="main-sobre" style="">
                    <p style="padding: 55px 20px 20px 20px;">
                        <span style="padding-left:25px;">A</span> Road Runner Cross Bikes atua no mercado de  vendas, montagem, acondicionamento Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vulputate odio ut enim blandit. Magna sit amet purus gravida quis. Dolor sit amet consectetur adipiscing elit ut aliquam purus sit. Vel pretium lectus quam id leo. Sit amet massa vitae tortor condimentum lacinia quis vel eros. Id ornare arcu odio ut sem. Leo integer malesuada eget arcu dictum varius. Erat pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Porttitor massa id neque aliquam. Id consectetur purus ut faucibus pulvinar. Nec feugiat nisl pretium fusce id velit ut tortor. Sit amet aliquam id diam. Id consectetur purus ut faucibus. Cras ornare arcu dui vivamus.

                    </p>
                </div>
                <div class="main-sobre" style="">
                    <p>
                        <img src="img/003.jpg" alt="" class="img-sobre"/>

                    </p>
                </div>
                <div class="main-sobre box-img-sobre" style="margin-left:776px;">
                    <p>


                    </p>
                </div>
            </div>
                <div>
                <div class="main-sobre box-img-sobre" style="margin: 333px 0px 0px 0px;">
                    <p>


                    </p>
                </div>
                <div class="main-sobre" style="">
                    <p>

                        <img src="img/001.jpg" alt="" class="img-sobre"/>
                    </p>
                </div>
                <div class="main-sobre" style="">
                    <p style="padding: 20px 20px 20px 20px;">
                        <span style="padding-left:25px;">O</span> objetivo da nossa empresa é a venda des Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vulputate odio ut enim blandit. Magna sit amet purus gravida quis. Dolor sit amet consectetur adipiscing elit ut aliquam purus sit. Vel pretium lectus quam id leo. Sit amet massa vitae tortor condimentum lacinia quis vel eros. Id ornare arcu odio ut sem. Leo integer malesuada eget arcu dictum varius. Erat pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Porttitor massa id neque aliquam. Id consectetur purus ut faucibus pulvinar. Nec feugiat nisl pretium fusce id velit ut tortor. Sit amet aliquam id diam. Id consectetur purus ut faucibus. Cras ornare arcu dui vivamus.

                    </p>
                </div>
            </div>
                <div>
                <div class="main-sobre" style="">
                    <p style="padding: 20px 20px 20px 20px;">
                        <span style="padding-left:25px;">Em 2014</span>, a Road Runner Cross Bikes completa 10 anos de mercado e dado seu crescimento e sua evolução a empresa está passando por uma reestruturação adotando o Lorem ipsum dolor sit amet,consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vulputate odio ut enim blandit. Magna sit amet purus gravida quis. Dolor sit amet consectetur adipiscing elit ut aliquam purus sit. Vel pretium lectus quam id leo. Sit amet massa vitae tortor condimentum lacinia quis vel eros. Id ornare arcu odio ut sem. Leo integer malesuada eget arcu dictum varius. Erat pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Porttitor massa id neque aliquam. Id consectetur purus ut faucibus pulvinar. Nec feugiat nisl pretium fusce id velit ut tortor. Sit amet aliquam id diam. Id consectetur purus ut faucibus. Cras ornare arcu dui vivamus.

                    </p>
                </div>
                <div class="main-sobre" >
                    <p>

                        <img src="img/002.jpg" alt="" class="img-sobre"/>
                    </p>
                </div>
                <div class="main-sobre box-img-sobre" style="margin: 666px 0px 0px 776px;">
                    <p>


                    </p>
                </div>
            </div>
                <?php

                    require_once("redes.php");

                ?>
            </div>
        </div>
        <?php

            require_once("footer.php");

        ?>
    </body>
</html>