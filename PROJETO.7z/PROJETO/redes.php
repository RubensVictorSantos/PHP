<?php

    echo('<div id="redes">
        <div class="box-redes">
            <a href="https://www.facebook.com/">
                <img src="img/ico/facebook.png" alt="Facebook" height="64" width="64">
            </a>
        </div>

        <div class="box-redes">
            <a href="https://www.twitter.com/">
                <img src="img/ico/twitter.png" alt="Twitter" height="64" width="64">
            </a>
        </div>

        <div class="box-redes">
            <a href="https://www.youtube.com/">
                <img src="img/ico/youtube.png" alt="Youtube" height="64" width="64">
            </a>
        </div>
    </div>');

?>