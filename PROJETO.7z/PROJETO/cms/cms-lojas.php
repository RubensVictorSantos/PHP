<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>
            CMS Lojas
        </title>
        
        <link rel="icon" href="../img/ico/i405_TDM_icon_bike93.gif">
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <div id="box-main" class="center">
            <?php
                require_once('cms-menu.php');
    
            ?>
            <div id="conteudo">
                <div class="titulos-cms">
                    <h3>Página Nossas lojas</h3>
                </div>

            </div>
            <div id="footer">
                <h3>
                    Desenvolvido por: Rubens Victor
                </h3>
            
            </div>
        </div>
    </body>
</html>