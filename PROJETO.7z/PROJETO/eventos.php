<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>
            Eventos
        </title>
        <link rel="icon" href="img/ico/i405_TDM_icon_bike93.gif">
    </head>
    <body>
        <?php
        
            require_once('menu.php');
        
        ?>
        <div id="conteudo" class="center" >
        
            
            <div class="container-evento">
                <div class="box-evento">
                    <div class="box-img-evento center">
                        <img src="img/festival-bike-sp.jpg" alt="" class="img-evento">
                    </div>
                    <div class="texto-evento center">
                    
                    </div>
                </div>
                <div class="box-evento">
                    <div class="box-img-evento center">
                        <img src="img/cycle-fair.png" alt="" class="img-evento">
                    </div>
                    <div class="texto-evento center">
                    
                    </div>
                </div>
            </div>
            
            <div class="container-evento">
                <div class="box-evento">
                    <div class="box-img-evento center">
                        <img src="img/001.jpg" alt="" class="img-evento">
                    </div>
                    <div class="texto-evento center">
                    
                    </div>
                </div>
                <div class="box-evento">
                    <div class="box-img-evento center">
                        <img src="img/2017-epic-final.jpg" alt="" class="img-evento">
                    </div>
                    <div class="texto-evento center">
                    
                    </div>
                </div>
            </div>
            
        </div>
        <?php
        
            require_once('footer.php');
        
        ?>
    </body>
</html>
